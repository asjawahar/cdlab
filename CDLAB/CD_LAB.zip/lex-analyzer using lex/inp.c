#include<stdio.h>

void main()
{
    int a, b, c;
    printf("enter the value for a,b");
    scanf("%d%d", &a, &b);
    c = a + b;
    printf("the value of c: %d", c);
}
